#include <iostream>
#include "my_lab.h"
using namespace std;

int main() {
	Rectangle a;
	a.set(4, 18);
	a.print();
	
	//a.help();

	system("PAUSE");
	return 0;
}
