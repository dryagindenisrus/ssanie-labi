#include <iostream>
#include "my_lab.h"
#include <string>

using namespace std;

Rectangle::Rectangle() {}

Rectangle::~Rectangle() {}

void Rectangle::set(float height, float width) {
	if (height <=20.0 && height > 0.0) {
		this -> height = height;
	} else {
		throw invalid_argument("parametr HEIGHT \">0\" and \"<=20\"");
	}
	if (width <=20 && width > 0) {
		this -> width = width;
	} else {
		throw invalid_argument("parametr WIDTH \">0\" and \"<=20\"");
	}	
}

float Rectangle::getHeight() {
	return height;
}

float Rectangle::getWidth() {
	return width;
}

float Rectangle::area() {
	return width * height;
}

float Rectangle::perimetr() {
	return 2 * (width + height);
}

void Rectangle::print() {
	int height_p = height;
	int width_p = width;

	for (int i=0; i<height_p; i++) {
		for (int j = 0; j < width_p; j++) {
			cout << char(219);
		}
		cout << "\n";
	}
}

void Rectangle::help() {
	string head = "\nclass\"Rectangle\"\n";
	string part1 = "For initialization, use the construction: Rectangle var;\n";
	string important = "\x1b[31mIMPORTANT\x1b[0m: the class uses private fields, so you need to set parameters only through the getHeight() and getWidth() methods.\n\n";
	string methods = "Class methods:\n\x1b[32mset\x1b[0m(float height, float width) - sets the parameters of the rectangle.\n\x1b[32mgetWidth\x1b[0m() - return the width of the rectangle\n\x1b[32mgetHeight\x1b[0m() - return the height of the rectangle\n\x1b[32marea\x1b[0m() - return the area of the rectangle\n\x1b[32mperimeter\x1b[0m() - return the perimeter of the rectangle\n\x1b[32mprint\x1b[0m() - print a triangle to the console in graphical representation";

	cout << head << part1 << important << methods << endl;
}